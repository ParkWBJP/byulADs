from __future__ import print_function
import os.path
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload

# 🔐 필요한 권한
SCOPES = ['https://www.googleapis.com/auth/drive.file']

# 📁 Google Drive 폴더 ID (BYUL_Backup)
FOLDER_ID = '1czSKDd0QrVdobRrDY7ZpELph8npstJhm'

def upload_latest_zip():
    zip_files = [f for f in os.listdir() if f.endswith(".zip")]
    if not zip_files:
        print("❌ ZIP 파일이 없습니다.")
        return
    latest_zip = max(zip_files, key=os.path.getctime)

    creds = None
    if os.path.exists('token.json'):
        creds = Credentials.from_authorized_user_file('token.json', SCOPES)
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(
                'credentials.json', SCOPES)
            creds = flow.run_local_server(port=0)
        with open('token.json', 'w') as token:
            token.write(creds.to_json())

    service = build('drive', 'v3', credentials=creds)

    file_metadata = {
        'name': latest_zip,
        'parents': [FOLDER_ID]
    }
    media = MediaFileUpload(latest_zip, mimetype='application/zip')
    file = service.files().create(body=file_metadata, media_body=media, fields='id').execute()
    print(f"✅ 업로드 완료: {latest_zip} (File ID: {file.get('id')})")

if __name__ == '__main__':
    upload_latest_zip()
